import { useState } from "react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, RadarChart, Radar, PolarGrid, PolarAngleAxis, PolarRadiusAxis, PieChart, Pie, Cell, LineChart, Line, Legend } from "recharts";

const NAVY = "#1E2761";
const TEAL = "#0D9488";
const DARK = "#1E293B";
const GRAY = "#64748B";
const GREEN = "#059669";
const RED = "#DC2626";
const AMBER = "#D97706";

const tabs = ["Overview", "Evidence", "Neuroscience", "Persona", "Pricing", "Revenue", "Risks", "Timeline"];

// ===== DATA =====
const evidenceData = [
  { id: "1A", name: "Pain Language", signal: "Strong", finding: '"I freeze up" at scale across 8 subreddits. 100-300+ upvotes per thread.' },
  { id: "1B", name: "Post-Conversation Regret", signal: "Strong", finding: "Millions replay conversations. No structured tool exists to help." },
  { id: "1C", name: "Book Review Gaps", signal: "Nuclear", finding: '"Great concepts but couldn\'t apply in real life." Books do customer acquisition for KDENZ.' },
  { id: "1D", name: "Competitor Churn", signal: "Strong", finding: "All competitors built for presentations/sales — interpersonal conversations unserved." },
  { id: "1E", name: "Market Sizing", signal: "Strong", finding: "Conflict resolution growing 7-11% CAGR. Hundreds of billions in adjacent markets." },
  { id: "2A", name: "Pricing Validation", signal: "Strong", finding: "$49/mo sits in proven sweet spot between habit apps ($10-20) and therapy ($60-100)." },
  { id: "2B", name: "Buyer Persona", signal: "Strong", finding: "35-50, mid-career, trigger-driven conversion window of 1-3 months." },
  { id: "2C", name: "Behavioral Validation", signal: "Strong", finding: "Record-and-review is real behavior. Privacy-first design required." },
  { id: "2D", name: "White Space", signal: "Strong", finding: "No direct competitor exists. Not a graveyard — an execution gap." },
  { id: "3A", name: "Neuroscience", signal: "Strong", finding: "All 5 mechanisms peer-reviewed: freeze response, reconsolidation, prosody, MI, practice." },
];

const neuroData = [
  { mechanism: "Freeze Response", citation: "Arnsten 2009 (Nat Rev Neurosci)", detail: "Catecholamines suppress dlPFC under social-evaluative threat. Working memory and top-down control impaired.", feature: "Stress inoculation through graded AI practice scenarios", gap: "Nobody addresses amygdala hijack mechanism" },
  { mechanism: "Memory Reconsolidation", citation: "Nader 2000 (Nature), Schiller 2010 (Nature)", detail: "Emotional memories become labile on retrieval. New information during reconsolidation window updates the memory trace.", feature: "Post-conversation review rewrites freeze-and-regret patterns", gap: "No competitor uses reconsolidation framing" },
  { mechanism: "Voice Diagnostics", citation: "Porges 2007 (Biol Psychol)", detail: "Polyvagal theory: cardiac vagal tone linked to vocal flexibility. High vagal tone → smooth prosody → safety signal.", feature: "Voice analytics detect autonomic nervous system state", gap: "Text-based coaches miss primary diagnostic signal" },
  { mechanism: "MI Autonomy", citation: "Zhang 2014 (J Subst Abuse Treat)", detail: "fMRI: spontaneous change talk activates self-referential and reward-related networks more than prompted repetition.", feature: "Self-discovery coaching beats directive advice neurologically", gap: "Directive coaching apps can't match this" },
  { mechanism: "Deliberate Practice", citation: "Ericsson 1993, Street 2009", detail: "Communication-skills gains stabilize at 4-12 weeks with structured feedback. Brain reorganization within days.", feature: "Measurable progress tracking with specific neuroplasticity timeline", gap: "Generic apps can't anchor to timelines" },
];

const radarData = [
  { dim: "Pain Signal", score: 95 },
  { dim: "White Space", score: 90 },
  { dim: "Price Valid.", score: 85 },
  { dim: "Neuro Evidence", score: 95 },
  { dim: "Buyer Clarity", score: 88 },
  { dim: "Revenue Model", score: 82 },
];

const pricingLandscape = [
  { tier: "Habit Apps", low: 10, high: 20, examples: "Headspace, Calm, Duolingo", position: "Below" },
  { tier: "Speech Coaching", low: 6, high: 30, examples: "Yoodli, Poised, Orai", position: "Below" },
  { tier: "AI Roleplay", low: 30, high: 45, examples: "VirtualSpeech, SecondNature", position: "Adjacent" },
  { tier: "KDENZ", low: 49, high: 49, examples: "Sweet Spot", position: "Target" },
  { tier: "Premium Coach", low: 60, high: 100, examples: "BetterUp, Noom Coach", position: "Above" },
  { tier: "Human Coaching", low: 300, high: 600, examples: "Executive coaches", position: "Far Above" },
];

const revenueScenarios = [
  { scenario: "Conservative", users: 5000, mrr: 245000, arr: 2900000, comparable: "SnoreLab" },
  { scenario: "Moderate", users: 15000, mrr: 735000, arr: 8800000, comparable: "PLAUD AI" },
  { scenario: "Aspirational", users: 20000, mrr: 980000, arr: 11800000, comparable: "Waking Up" },
];

const comparableApps = [
  { name: "Waking Up", downloads: "20K", revenue: "$900K/mo", perDL: "$45", category: "Meditation" },
  { name: "PLAUD AI", downloads: "60K", revenue: "$900K/mo", perDL: "$15", category: "Voice AI" },
  { name: "Sweat", downloads: "40K", revenue: "$1M/mo", perDL: "$25", category: "Fitness" },
  { name: "SnoreLab", downloads: "90K", revenue: "$300K/mo", perDL: "$3.33", category: "Record+Analyze" },
  { name: "TapeACall", downloads: "40K", revenue: "$400K/mo", perDL: "$10", category: "Voice" },
  { name: "RadarScope", downloads: "10K", revenue: "$300K/mo", perDL: "$30", category: "Niche Utility" },
];

const risks = [
  { id: 1, risk: "HIGH", title: "Recording Adoption", desc: "Will people record sensitive conversations even with privacy-first design?", test: "Interview Q15-16. Measure willingness 1-10 for practice vs. real separately.", mitigation: "Practice-first onboarding. On-device processing. Delete-after-analysis option." },
  { id: 2, risk: "HIGH", title: "Price Conversion", desc: "Does $49/mo trigger credit cards, not just stated interest?", test: "Van Westendorp questions. Look for price sensitivity cliff.", mitigation: "If optimal clusters at $25-35, add premium tier or reduce to $39." },
  { id: 3, risk: "MED", title: "Feedback Quality", desc: "Can voice analytics produce specific actionable insights?", test: "Technical prototype with 10 recorded conversations. Score specificity 1-5.", mitigation: "Supplement Hume AI with custom NLP. Combine voice + text analysis." },
  { id: 4, risk: "MED", title: "Session 2 Return", desc: "Does first session deliver an 'aha moment'?", test: "10-user prototype test. Measure voluntary return rate.", mitigation: "First session targets one high-impact metric (e.g., tension-calming score)." },
  { id: 5, risk: "LOW", title: "MD Credential Impact", desc: "Does physician credential help or confuse?", test: "Interview Q17. A/B test landing page.", mitigation: "Frame as 'neuroscience researcher' if MD confuses." },
];

const timelineData = [
  { week: "1-2", task: "Van Westendorp Interviews", detail: "15-20 interviews with LinkedIn managers & HR", status: "next" },
  { week: "3", task: "Analyze Interview Data", detail: "Price sensitivity, privacy barriers, feature priorities", status: "pending" },
  { week: "4-5", task: "Technical Prototype", detail: "Record → Hume AI → feedback display. Test 10 users.", status: "pending" },
  { week: "6", task: "Landing Page + Traffic", detail: "500 visitors via LinkedIn/Reddit ads. Email conversion.", status: "pending" },
  { week: "7-8", task: "Beta Launch", detail: "50 paying users at $49/mo. D7 retention, D30 churn.", status: "pending" },
];

const pieData = [
  { name: "Managers", value: 30 },
  { name: "HR Pros", value: 22 },
  { name: "Healthcare", value: 18 },
  { name: "Lawyers", value: 12 },
  { name: "Consultants", value: 10 },
  { name: "Educators", value: 8 },
];
const COLORS = [TEAL, NAVY, GREEN, AMBER, "#6366F1", "#EC4899"];

function Badge({ text, color }) {
  const bg = color === "green" ? "bg-emerald-100 text-emerald-800" : color === "red" ? "bg-red-100 text-red-800" : color === "amber" ? "bg-amber-100 text-amber-800" : "bg-teal-100 text-teal-800";
  return <span className={`inline-block px-2 py-0.5 rounded-full text-xs font-semibold ${bg}`}>{text}</span>;
}

// ===== TAB COMPONENTS =====

function OverviewTab() {
  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-emerald-600 to-teal-700 rounded-xl p-6 text-white">
        <div className="flex items-center gap-3 mb-3">
          <div className="text-4xl font-bold">GO</div>
          <div className="text-sm opacity-90 leading-tight">10 independent research prompts.<br/>Zero red flags. This is rare.</div>
        </div>
        <p className="text-sm opacity-80">KDENZ Voice Lab occupies a genuine white space at the intersection of AI/Productivity, Health/Wellness, and Mindfulness — three proven high-ARPU app categories — with zero direct consumer-facing competitors.</p>
      </div>

      <div className="grid grid-cols-4 gap-3">
        {[
          { num: "10/10", label: "Prompts Passed", color: "text-emerald-600" },
          { num: "$49/mo", label: "Validated Price", color: "text-teal-600" },
          { num: "0", label: "Direct Competitors", color: "text-blue-600" },
          { num: "5", label: "Neuroscience Mechanisms", color: "text-purple-600" },
        ].map((s, i) => (
          <div key={i} className="bg-white rounded-lg p-4 border border-slate-200 text-center shadow-sm">
            <div className={`text-2xl font-bold ${s.color}`}>{s.num}</div>
            <div className="text-xs text-slate-500 mt-1">{s.label}</div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="bg-white rounded-lg p-4 border border-slate-200 shadow-sm">
          <h3 className="text-sm font-bold text-slate-800 mb-3">Market Validation Strength</h3>
          <ResponsiveContainer width="100%" height={220}>
            <RadarChart data={radarData}>
              <PolarGrid stroke="#e2e8f0" />
              <PolarAngleAxis dataKey="dim" tick={{ fontSize: 10, fill: GRAY }} />
              <PolarRadiusAxis domain={[0, 100]} tick={false} axisLine={false} />
              <Radar dataKey="score" stroke={TEAL} fill={TEAL} fillOpacity={0.25} strokeWidth={2} />
            </RadarChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white rounded-lg p-4 border border-slate-200 shadow-sm">
          <h3 className="text-sm font-bold text-slate-800 mb-3">Positioning Statement</h3>
          <div className="bg-slate-50 rounded-lg p-3 border-l-4 border-teal-500">
            <p className="text-xs text-slate-700 italic leading-relaxed">
              KDENZ Voice Lab is the first consumer AI product that analyzes how you actually sound in difficult conversations, rewires the freeze response through evidence-based reconsolidation, and builds lasting skill through deliberate practice — designed by a triple board-certified physician.
            </p>
          </div>
          <div className="mt-3 space-y-1">
            {['"Retrain your brain for difficult conversations"', '"The missing chapter after every communication book"', '"Your voice reveals what words can\'t"'].map((t, i) => (
              <div key={i} className="text-xs text-teal-700 bg-teal-50 rounded px-2 py-1">{t}</div>
            ))}
          </div>
        </div>
      </div>

      <div className="bg-slate-800 rounded-xl p-4 text-white">
        <h3 className="text-sm font-bold mb-2 text-teal-400">Competitive Moat Summary</h3>
        <div className="grid grid-cols-5 gap-2">
          {["Train freeze response", "Rewrite emotional memory", "Voice reveals nervous system", "Self-discovery > advice", "Change in 4-12 weeks"].map((c, i) => (
            <div key={i} className="bg-slate-700 rounded-lg p-2 text-center">
              <div className="text-xs text-teal-300 font-medium">{c}</div>
            </div>
          ))}
        </div>
        <p className="text-xs text-slate-400 mt-2">Five claims backed by peer-reviewed neuroscience that no competitor can make.</p>
      </div>
    </div>
  );
}

function EvidenceTab() {
  const [selected, setSelected] = useState(null);
  return (
    <div className="space-y-4">
      <div className="bg-white rounded-lg border border-slate-200 overflow-hidden shadow-sm">
        <div className="bg-slate-800 px-4 py-2">
          <h3 className="text-sm font-bold text-white">Validation Evidence Matrix — 10 Prompts</h3>
        </div>
        <table className="w-full text-xs">
          <thead>
            <tr className="bg-slate-50 border-b border-slate-200">
              <th className="px-3 py-2 text-left text-slate-500 font-medium">ID</th>
              <th className="px-3 py-2 text-left text-slate-500 font-medium">Research Prompt</th>
              <th className="px-3 py-2 text-left text-slate-500 font-medium">Signal</th>
              <th className="px-3 py-2 text-left text-slate-500 font-medium">Key Finding</th>
            </tr>
          </thead>
          <tbody>
            {evidenceData.map((row, i) => (
              <tr key={i} className={`border-b border-slate-100 cursor-pointer hover:bg-teal-50 transition-colors ${selected === i ? "bg-teal-50" : ""}`} onClick={() => setSelected(selected === i ? null : i)}>
                <td className="px-3 py-2.5 font-mono font-bold text-slate-700">{row.id}</td>
                <td className="px-3 py-2.5 font-medium text-slate-800">{row.name}</td>
                <td className="px-3 py-2.5"><Badge text={row.signal === "Nuclear" ? "🔥 NUCLEAR" : "✅ STRONG"} color={row.signal === "Nuclear" ? "amber" : "green"} /></td>
                <td className="px-3 py-2.5 text-slate-600">{row.finding}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="grid grid-cols-3 gap-3">
        <div className="bg-emerald-50 rounded-lg p-4 border border-emerald-200">
          <div className="text-lg font-bold text-emerald-700">Phase 1</div>
          <div className="text-xs text-emerald-600 font-medium">Signal Mining</div>
          <div className="text-xs text-slate-600 mt-2">5/5 prompts strong. Pain is real, at scale, and unserved. Books are doing customer acquisition.</div>
        </div>
        <div className="bg-blue-50 rounded-lg p-4 border border-blue-200">
          <div className="text-lg font-bold text-blue-700">Phase 2</div>
          <div className="text-xs text-blue-600 font-medium">Willingness to Pay</div>
          <div className="text-xs text-slate-600 mt-2">4/4 prompts strong. $49/mo validated. Persona clear. White space confirmed — not a graveyard.</div>
        </div>
        <div className="bg-purple-50 rounded-lg p-4 border border-purple-200">
          <div className="text-lg font-bold text-purple-700">Phase 3</div>
          <div className="text-xs text-purple-600 font-medium">Neuroscience Validation</div>
          <div className="text-xs text-slate-600 mt-2">1/1 prompts strong. All 5 mechanisms have peer-reviewed backing. Every one maps to a product feature.</div>
        </div>
      </div>
    </div>
  );
}

function NeuroscienceTab() {
  const [expanded, setExpanded] = useState(null);
  return (
    <div className="space-y-3">
      <div className="bg-slate-800 rounded-xl p-4 mb-4">
        <h3 className="text-sm font-bold text-teal-400 mb-1">The Neuroscience Moat</h3>
        <p className="text-xs text-slate-300">Every mechanism maps directly to a KDENZ product feature. No speech coaching app, AI chatbot, or relationship app has this research base integrated into product design.</p>
      </div>

      {neuroData.map((item, i) => (
        <div key={i} className="bg-white rounded-lg border border-slate-200 overflow-hidden shadow-sm cursor-pointer" onClick={() => setExpanded(expanded === i ? null : i)}>
          <div className="flex items-center gap-3 px-4 py-3">
            <div className="w-1 h-10 rounded-full bg-teal-500 flex-shrink-0" />
            <div className="flex-1">
              <div className="text-sm font-bold text-slate-800">{item.mechanism}</div>
              <div className="text-xs text-teal-600">{item.citation}</div>
            </div>
            <div className="text-xs text-slate-400">{expanded === i ? "▲" : "▼"}</div>
          </div>
          {expanded === i && (
            <div className="px-4 pb-4 space-y-2 border-t border-slate-100 pt-3">
              <div>
                <div className="text-xs font-semibold text-slate-500 mb-1">MECHANISM</div>
                <div className="text-xs text-slate-700">{item.detail}</div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="bg-teal-50 rounded p-2">
                  <div className="text-xs font-semibold text-teal-700 mb-1">PRODUCT FEATURE</div>
                  <div className="text-xs text-slate-700">{item.feature}</div>
                </div>
                <div className="bg-red-50 rounded p-2">
                  <div className="text-xs font-semibold text-red-700 mb-1">COMPETITOR GAP</div>
                  <div className="text-xs text-slate-700">{item.gap}</div>
                </div>
              </div>
            </div>
          )}
        </div>
      ))}
    </div>
  );
}

function PersonaTab() {
  return (
    <div className="space-y-4">
      <div className="bg-white rounded-lg p-4 border border-slate-200 shadow-sm">
        <h3 className="text-sm font-bold text-slate-800 mb-1">"The Stressed-But-Driven Leader"</h3>
        <p className="text-xs text-slate-500">35-50 years old • Mid-to-senior career • 56-63% female • Communication-heavy roles • Already investing in self-improvement</p>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="bg-white rounded-lg border-2 border-teal-300 overflow-hidden shadow-sm">
          <div className="bg-teal-600 px-4 py-2">
            <div className="text-sm font-bold text-white">Growth-Oriented Achievers</div>
            <div className="text-xs text-teal-100">Core Segment • Lower Churn • Higher LTV</div>
          </div>
          <div className="p-4 space-y-2 text-xs">
            <div><span className="font-semibold text-slate-700">Values:</span> <span className="text-slate-600">Growth mindset, accountability, measurable progress</span></div>
            <div><span className="font-semibold text-slate-700">Fear:</span> <span className="text-slate-600">Passed over for promotion due to poor soft skills</span></div>
            <div><span className="font-semibold text-slate-700">Aspiration:</span> <span className="text-slate-600">Confident, empathetic leader with influence</span></div>
            <div className="bg-teal-50 rounded p-2 italic text-teal-700">"Turn difficult conversations into career leverage"</div>
            <div><span className="font-semibold text-slate-700">MD angle:</span> <span className="text-slate-600">"Evidence-based methodology"</span></div>
          </div>
        </div>

        <div className="bg-white rounded-lg border-2 border-slate-300 overflow-hidden shadow-sm">
          <div className="bg-slate-700 px-4 py-2">
            <div className="text-sm font-bold text-white">Anxiety-Driven Avoiders</div>
            <div className="text-xs text-slate-300">Secondary • Higher Volume • Churn Risk</div>
          </div>
          <div className="p-4 space-y-2 text-xs">
            <div><span className="font-semibold text-slate-700">Values:</span> <span className="text-slate-600">Emotional safety, stress reduction, avoiding confrontation</span></div>
            <div><span className="font-semibold text-slate-700">Fear:</span> <span className="text-slate-600">Being "found out" as awkward or tone-deaf</span></div>
            <div><span className="font-semibold text-slate-700">Aspiration:</span> <span className="text-slate-600">Feel less anxious, minimize friction in conversations</span></div>
            <div className="bg-slate-50 rounded p-2 italic text-slate-700">"Practice in a safe space so you don't freeze"</div>
            <div><span className="font-semibold text-slate-700">MD angle:</span> <span className="text-slate-600">"Physician-designed, judgment-free"</span></div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="bg-white rounded-lg p-4 border border-slate-200 shadow-sm">
          <h3 className="text-sm font-bold text-slate-800 mb-3">High-Need Professions</h3>
          <ResponsiveContainer width="100%" height={200}>
            <PieChart>
              <Pie data={pieData} cx="50%" cy="50%" outerRadius={80} dataKey="value" label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}>
                {pieData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white rounded-lg p-4 border border-slate-200 shadow-sm">
          <h3 className="text-sm font-bold text-slate-800 mb-3">Triggering Events (1-3 Month Window)</h3>
          <div className="space-y-2">
            {["New promotion to management role", "Bad performance review / PIP", "Failed negotiation or conflict escalation", "Preparing for salary negotiation", "Divorce, custody, major family conflict"].map((e, i) => (
              <div key={i} className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-teal-500 flex-shrink-0" />
                <span className="text-xs text-slate-700">{e}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function PricingTab() {
  const barData = pricingLandscape.map(p => ({
    name: p.tier,
    low: p.low,
    high: p.high - p.low,
    isKdenz: p.tier === "KDENZ",
  }));

  return (
    <div className="space-y-4">
      <div className="bg-white rounded-lg p-4 border border-slate-200 shadow-sm">
        <h3 className="text-sm font-bold text-slate-800 mb-1">Pricing Sweet Spot: $49/month</h3>
        <p className="text-xs text-slate-500">Less than a single coaching session. More effective than any book. Progress metrics required for retention at this tier.</p>
      </div>

      <div className="bg-white rounded-lg p-4 border border-slate-200 shadow-sm">
        <h3 className="text-sm font-bold text-slate-800 mb-3">Competitive Pricing Landscape</h3>
        <ResponsiveContainer width="100%" height={250}>
          <BarChart data={barData} layout="vertical" margin={{ left: 90 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
            <XAxis type="number" domain={[0, 650]} tick={{ fontSize: 10, fill: GRAY }} tickFormatter={v => `$${v}`} />
            <YAxis type="category" dataKey="name" tick={{ fontSize: 11, fill: DARK }} width={85} />
            <Tooltip formatter={(v, name) => [`$${v}`, name === "low" ? "Low" : "Range"]} />
            <Bar dataKey="low" stackId="a" fill="#e2e8f0" />
            <Bar dataKey="high" stackId="a" fill={TEAL} />
          </BarChart>
        </ResponsiveContainer>
      </div>

      <div className="grid grid-cols-3 gap-3">
        <div className="bg-amber-50 rounded-lg p-3 border border-amber-200">
          <div className="text-xs font-bold text-amber-700">⚠️ The 90-Day Rule</div>
          <div className="text-xs text-slate-600 mt-1">At $30-50/mo, consumers cancel if they don't see measurable improvement in 30-90 days. Progress metrics are retention requirement.</div>
        </div>
        <div className="bg-teal-50 rounded-lg p-3 border border-teal-200">
          <div className="text-xs font-bold text-teal-700">✅ Neuroscience Timeline</div>
          <div className="text-xs text-slate-600 mt-1">Kleim & Jones 2008 + Street 2009: Communication gains stabilize at 4-12 weeks. Subscription pays for itself by week 4-6.</div>
        </div>
        <div className="bg-blue-50 rounded-lg p-3 border border-blue-200">
          <div className="text-xs font-bold text-blue-700">💡 Anchor Message</div>
          <div className="text-xs text-slate-600 mt-1">"$49/month is less than one coaching session." Executive coaching: $200-600/hr. Harvard PON: $2,497-3,494.</div>
        </div>
      </div>
    </div>
  );
}

function RevenueTab() {
  const chartData = revenueScenarios.map(s => ({
    name: s.scenario,
    ARR: s.arr / 1000000,
    MRR: s.mrr / 1000,
  }));

  return (
    <div className="space-y-4">
      <div className="bg-teal-50 rounded-xl p-4 border border-teal-200">
        <p className="text-sm font-bold text-teal-800">You don't need millions of users. You need 5,000-20,000 committed professionals paying $49/month.</p>
        <p className="text-xs text-teal-600 mt-1">Validated by 148 high-revenue, low-download apps across fitness, meditation, voice recording, and professional tools.</p>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="bg-white rounded-lg p-4 border border-slate-200 shadow-sm">
          <h3 className="text-sm font-bold text-slate-800 mb-3">Revenue Projections at $49/mo</h3>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis dataKey="name" tick={{ fontSize: 10, fill: GRAY }} />
              <YAxis tick={{ fontSize: 10, fill: GRAY }} tickFormatter={v => `$${v}M`} />
              <Tooltip formatter={(v) => [`$${v.toFixed(1)}M`, "ARR"]} />
              <Bar dataKey="ARR" fill={TEAL} radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white rounded-lg p-4 border border-slate-200 shadow-sm">
          <h3 className="text-sm font-bold text-slate-800 mb-3">Comparable App Revenue</h3>
          <div className="space-y-2">
            {comparableApps.map((app, i) => (
              <div key={i} className="flex items-center justify-between py-1.5 border-b border-slate-100 last:border-0">
                <div>
                  <div className="text-xs font-semibold text-slate-800">{app.name}</div>
                  <div className="text-xs text-slate-400">{app.category}</div>
                </div>
                <div className="text-right">
                  <div className="text-xs font-semibold text-teal-600">{app.revenue}</div>
                  <div className="text-xs text-slate-400">{app.downloads} DL • {app.perDL}/DL</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg border border-slate-200 overflow-hidden shadow-sm">
        <div className="bg-slate-800 px-4 py-2">
          <h3 className="text-sm font-bold text-white">Scenario Detail</h3>
        </div>
        <table className="w-full text-xs">
          <thead>
            <tr className="bg-slate-50 border-b">
              <th className="px-3 py-2 text-left text-slate-500">Scenario</th>
              <th className="px-3 py-2 text-right text-slate-500">Subscribers</th>
              <th className="px-3 py-2 text-right text-slate-500">Monthly MRR</th>
              <th className="px-3 py-2 text-right text-slate-500">Annual ARR</th>
              <th className="px-3 py-2 text-left text-slate-500">Comparable</th>
            </tr>
          </thead>
          <tbody>
            {revenueScenarios.map((s, i) => (
              <tr key={i} className={`border-b border-slate-100 ${i === 1 ? "bg-teal-50" : ""}`}>
                <td className={`px-3 py-2.5 font-semibold ${i === 1 ? "text-teal-700" : "text-slate-700"}`}>{s.scenario}</td>
                <td className="px-3 py-2.5 text-right text-slate-600">{s.users.toLocaleString()}</td>
                <td className="px-3 py-2.5 text-right text-slate-600">${s.mrr.toLocaleString()}</td>
                <td className={`px-3 py-2.5 text-right font-bold ${i === 1 ? "text-teal-700" : "text-slate-700"}`}>${(s.arr / 1000000).toFixed(1)}M</td>
                <td className="px-3 py-2.5 text-slate-500">{s.comparable} tier</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function RisksTab() {
  return (
    <div className="space-y-3">
      <div className="bg-slate-50 rounded-lg p-3 border border-slate-200">
        <p className="text-xs text-slate-600">Despite overwhelmingly positive desk research, five assumptions remain untested. These are ranked by risk and should drive customer discovery interviews.</p>
      </div>
      {risks.map((r, i) => (
        <div key={i} className="bg-white rounded-lg border border-slate-200 p-4 shadow-sm">
          <div className="flex items-start gap-3">
            <div className={`px-2 py-1 rounded text-xs font-bold text-white flex-shrink-0 ${r.risk === "HIGH" ? "bg-red-500" : r.risk === "MED" ? "bg-amber-500" : "bg-emerald-500"}`}>
              {r.risk}
            </div>
            <div className="flex-1">
              <div className="text-sm font-bold text-slate-800">{r.title}</div>
              <div className="text-xs text-slate-600 mt-1">{r.desc}</div>
              <div className="grid grid-cols-2 gap-3 mt-3">
                <div className="bg-blue-50 rounded p-2">
                  <div className="text-xs font-semibold text-blue-700 mb-1">How to Test</div>
                  <div className="text-xs text-slate-600">{r.test}</div>
                </div>
                <div className="bg-emerald-50 rounded p-2">
                  <div className="text-xs font-semibold text-emerald-700 mb-1">Mitigation</div>
                  <div className="text-xs text-slate-600">{r.mitigation}</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

function TimelineTab() {
  return (
    <div className="space-y-4">
      <div className="bg-slate-800 rounded-xl p-4">
        <h3 className="text-sm font-bold text-teal-400 mb-1">8-Week Validation Sprint</h3>
        <p className="text-xs text-slate-300">From interviews to beta launch with 50 paying users.</p>
      </div>

      <div className="space-y-3">
        {timelineData.map((t, i) => (
          <div key={i} className="flex items-stretch gap-4">
            <div className="flex flex-col items-center">
              <div className={`w-10 h-10 rounded-full flex items-center justify-center text-xs font-bold text-white flex-shrink-0 ${t.status === "next" ? "bg-teal-500" : "bg-slate-300"}`}>
                W{t.week}
              </div>
              {i < timelineData.length - 1 && <div className="w-0.5 flex-1 bg-slate-200 mt-1" />}
            </div>
            <div className={`flex-1 rounded-lg p-4 border shadow-sm ${t.status === "next" ? "bg-teal-50 border-teal-300" : "bg-white border-slate-200"}`}>
              <div className="flex items-center gap-2">
                <div className="text-sm font-bold text-slate-800">{t.task}</div>
                {t.status === "next" && <Badge text="NEXT" color="teal" />}
              </div>
              <div className="text-xs text-slate-600 mt-1">{t.detail}</div>
            </div>
          </div>
        ))}
      </div>

      <div className="bg-amber-50 rounded-lg p-4 border border-amber-200">
        <h4 className="text-xs font-bold text-amber-700 mb-2">Decision Gates</h4>
        <div className="space-y-1 text-xs text-slate-700">
          <div>• <strong>Week 3:</strong> If Van Westendorp optimal price &lt; $35 → reposition or add premium tier</div>
          <div>• <strong>Week 3:</strong> If privacy is dealbreaker → pivot to practice-only (no real conversation upload) for V1</div>
          <div>• <strong>Week 5:</strong> If feedback specificity &lt; 3.5/5 → supplement Hume AI with custom NLP</div>
          <div>• <strong>Week 8:</strong> If D30 churn &gt; 40% → diagnose feedback quality vs. privacy vs. price</div>
        </div>
      </div>
    </div>
  );
}

// ===== MAIN APP =====
export default function App() {
  const [activeTab, setActiveTab] = useState(0);

  const TabContent = [OverviewTab, EvidenceTab, NeuroscienceTab, PersonaTab, PricingTab, RevenueTab, RisksTab, TimelineTab][activeTab];

  return (
    <div className="min-h-screen bg-slate-100">
      <div className="bg-gradient-to-r from-slate-800 to-slate-900 px-4 py-3">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <div>
            <h1 className="text-lg font-bold text-white tracking-tight">KDENZ Voice Lab</h1>
            <p className="text-xs text-slate-400">Strategic Intelligence Dashboard</p>
          </div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-1 bg-emerald-500 text-white text-xs font-bold rounded">VERDICT: GO</span>
            <span className="text-xs text-slate-400">Feb 2026</span>
          </div>
        </div>
      </div>

      <div className="bg-white border-b border-slate-200 sticky top-0 z-10 shadow-sm">
        <div className="max-w-6xl mx-auto flex overflow-x-auto">
          {tabs.map((tab, i) => (
            <button
              key={i}
              onClick={() => setActiveTab(i)}
              className={`px-4 py-2.5 text-xs font-medium whitespace-nowrap border-b-2 transition-colors ${
                activeTab === i
                  ? "border-teal-500 text-teal-700 bg-teal-50"
                  : "border-transparent text-slate-500 hover:text-slate-700 hover:bg-slate-50"
              }`}
            >
              {tab}
            </button>
          ))}
        </div>
      </div>

      <div className="max-w-6xl mx-auto p-4">
        <TabContent />
      </div>

      <div className="bg-slate-800 mt-6 px-4 py-3 text-center">
        <p className="text-xs text-slate-400">CONFIDENTIAL • KDENZ Voice Lab • Randy Nunez, MD • Triple Board-Certified Physician</p>
      </div>
    </div>
  );
}
